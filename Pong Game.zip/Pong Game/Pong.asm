
;  TWO-PLAYER PONG GAME


;  Group Members:
;    - Munawar  (Game Logic  : ball movement, collision, score)
;    - Faizan  (Input       : keyboard reading for both players)
;    - Abdullah  (Display     : drawing everything on screen)

;  How the game works:
;    The whole game is one loop that runs forever.
;    Every loop does these 4 things:
;      1. Check keyboard --> move paddles up or down
;      2. Move ball one step (add speed to position)
;      3. Check if ball hit wall, paddle, or went off edge
;      4. Redraw everything on screen
;    First player to score 5 points wins.

;  Controls:
;    Player 1 (LEFT  paddle, cyan)    W = up,  S = down
;    Player 2 (RIGHT paddle, yellow)  I = up,  K = down
;    ESC = quit


INCLUDE Irvine32.inc

;  CONSTANTS

SCREEN_W      EQU  78
SCREEN_H      EQU  23
TOP_ROW       EQU  2
BOT_ROW       EQU  22

P1_COL        EQU  3
P2_COL        EQU  75
PAD_HEIGHT    EQU  4

BALL_START_X  EQU  39
BALL_START_Y  EQU  12

WIN_SCORE     EQU  5

PADDLE_CH     EQU  219
BALL_CH       EQU  79
SPACE_CH      EQU  32

; colors
COL_P1        EQU  (black SHL 4) OR cyan
COL_P2        EQU  (black SHL 4) OR yellow
COL_BALL      EQU  (black SHL 4) OR white
COL_WALL      EQU  (black SHL 4) OR green
COL_SCORE     EQU  (black SHL 4) OR lightCyan
COL_ERASE     EQU  (black SHL 4) OR black
COL_TITLE     EQU  (black SHL 4) OR lightRed
COL_WIN       EQU  (black SHL 4) OR lightGreen

;  DATA SEGMENT

.data

ballX       BYTE  BALL_START_X
ballY       BYTE  BALL_START_Y
ballDX      SBYTE 1
ballDY      SBYTE 1

paddle1Y    BYTE  10
paddle2Y    BYTE  10

score1      BYTE  0
score2      BYTE  0

gameOver    BYTE  0

titleStr    BYTE  "*** TWO PLAYER PONG ***", 0
ctrlStr     BYTE  "P1: W/S    P2: I/K    ESC: Quit", 0
enterStr    BYTE  "Press ENTER to Start", 0
win1Str     BYTE  "*** PLAYER 1 WINS! ***  Press ENTER", 0
win2Str     BYTE  "*** PLAYER 2 WINS! ***  Press ENTER", 0

;  CODE SEGMENT
.code

;  MAIN
main PROC

    call    ShowSplash
    call    InitGame

GameLoop:
    call    ReadKeys
    call    MoveBall
    call    CheckCollision
    call    DrawEverything
    call    CheckWin
    call    GameDelay

    cmp     gameOver, 1
    jne     GameLoop

    call    ShowWinner
    call    WaitForEnter

    exit
main ENDP


;  Abdullah -- DISPLAY PROCEDURES

;  ShowSplash
ShowSplash PROC

    call    Clrscr

    mov     eax, COL_TITLE
    call    SetTextColor
    mov     dh, 8
    mov     dl, 28
    call    Gotoxy
    lea     edx, titleStr
    call    WriteString

    mov     eax, COL_SCORE
    call    SetTextColor
    mov     dh, 11
    mov     dl, 23
    call    Gotoxy
    lea     edx, ctrlStr
    call    WriteString

    mov     eax, COL_WALL
    call    SetTextColor
    mov     dh, 14
    mov     dl, 29
    call    Gotoxy
    lea     edx, enterStr
    call    WriteString

    call    WaitForEnter
    call    Clrscr

    ret
ShowSplash ENDP


;  DrawEverything
DrawEverything PROC

    ; -- top wall --
    mov     eax, COL_WALL
    call    SetTextColor
    mov     dh, TOP_ROW
    mov     dl, 0
    call    Gotoxy
    mov     ecx, SCREEN_W
TopWallLoop:
    mov     al, '-'
    call    WriteChar
    loop    TopWallLoop

    ; -- bottom wall --
    mov     dh, BOT_ROW
    mov     dl, 0
    call    Gotoxy
    mov     ecx, SCREEN_W
BotWallLoop:
    mov     al, '-'
    call    WriteChar
    loop    BotWallLoop

    ; -- center divider --
    mov     bl, TOP_ROW + 1
CenterLoop:
    cmp     bl, BOT_ROW
    jge     CenterDone
    mov     dh, bl
    mov     dl, 39
    call    Gotoxy
    mov     al, ':'
    call    WriteChar
    inc     bl
    jmp     CenterLoop
CenterDone:

    call    DrawPaddle1
    call    DrawPaddle2
    call    DrawBall
    call    DrawScore

    ret
DrawEverything ENDP


;  DrawPaddle1
DrawPaddle1 PROC

    mov     eax, COL_P1
    call    SetTextColor

    mov     cl, paddle1Y
    mov     bl, PAD_HEIGHT
P1DrawLoop:
    mov     dh, cl
    mov     dl, P1_COL
    call    Gotoxy
    mov     al, PADDLE_CH
    call    WriteChar
    inc     cl
    dec     bl
    jnz     P1DrawLoop

    ret
DrawPaddle1 ENDP



;  ErasePaddle1
ErasePaddle1 PROC

    mov     eax, COL_ERASE
    call    SetTextColor

    mov     cl, paddle1Y
    mov     bl, PAD_HEIGHT
P1EraseLoop:
    mov     dh, cl
    mov     dl, P1_COL
    call    Gotoxy
    mov     al, SPACE_CH
    call    WriteChar
    inc     cl
    dec     bl
    jnz     P1EraseLoop

    ret
ErasePaddle1 ENDP


;  DrawPaddle2

DrawPaddle2 PROC

    mov     eax, COL_P2
    call    SetTextColor

    mov     cl, paddle2Y
    mov     bl, PAD_HEIGHT
P2DrawLoop:
    mov     dh, cl
    mov     dl, P2_COL
    call    Gotoxy
    mov     al, PADDLE_CH
    call    WriteChar
    inc     cl
    dec     bl
    jnz     P2DrawLoop

    ret
DrawPaddle2 ENDP


;  ErasePaddle2
ErasePaddle2 PROC

    mov     eax, COL_ERASE
    call    SetTextColor

    mov     cl, paddle2Y
    mov     bl, PAD_HEIGHT
P2EraseLoop:
    mov     dh, cl
    mov     dl, P2_COL
    call    Gotoxy
    mov     al, SPACE_CH
    call    WriteChar
    inc     cl
    dec     bl
    jnz     P2EraseLoop

    ret
ErasePaddle2 ENDP



;  DrawBall
DrawBall PROC

    mov     eax, COL_BALL
    call    SetTextColor
    mov     dh, ballY
    mov     dl, ballX
    call    Gotoxy
    mov     al, BALL_CH
    call    WriteChar

    ret
DrawBall ENDP


;  EraseBall

EraseBall PROC

    mov     eax, COL_ERASE
    call    SetTextColor
    mov     dh, ballY
    mov     dl, ballX
    call    Gotoxy
    mov     al, SPACE_CH
    call    WriteChar

    ret
EraseBall ENDP


;  DrawScore


DrawScore PROC

   

    mov     eax, COL_SCORE
    call    SetTextColor

    ; --- Player 1 label: "P1:" at column 2 ---
    mov     dh, 0
    mov     dl, 2
    call    Gotoxy
    mov     al, 'P'
    call    WriteChar
    mov     al, '1'
    call    WriteChar
    mov     al, ':'
    call    WriteChar
    mov     al, ' '
    call    WriteChar

    ; --- Player 1 score digit ---
    ; score is 0-9 so just add '0' to convert to ASCII
    mov     dh, 0
    mov     dl, 6
    call    Gotoxy
    mov     al, score1          ; get score value
    add     al, '0'             ; convert number to ASCII digit
    call    WriteChar           ; print it

    ; --- Player 2 label: "P2:" at column 55 ---
    mov     dh, 0
    mov     dl, 55
    call    Gotoxy
    mov     al, 'P'
    call    WriteChar
    mov     al, '2'
    call    WriteChar
    mov     al, ':'
    call    WriteChar
    mov     al, ' '
    call    WriteChar

    ; --- Player 2 score digit ---
    mov     dh, 0
    mov     dl, 59
    call    Gotoxy
    mov     al, score2
    add     al, '0'
    call    WriteChar

    ret
DrawScore ENDP


;  ShowWinner
ShowWinner PROC

    call    Clrscr
    mov     eax, COL_WIN
    call    SetTextColor
    mov     dh, 11
    mov     dl, 20
    call    Gotoxy

    ; compare the two scores -- whoever has MORE points wins
    ; this works for normal win AND when ESC is pressed early
    movzx   eax, score1
    movzx   ebx, score2
    cmp     eax, ebx
    ja      SW_P1Wins       ; score1 > score2 --> P1 wins
    jb      SW_P2Wins       ; score1 < score2 --> P2 wins

    ; scores are equal -- it's a draw (only happens on ESC)
    mov     dh, 11
    mov     dl, 20
    call    Gotoxy
    mov     al, 'D'
    call    WriteChar
    mov     al, 'R'
    call    WriteChar
    mov     al, 'A'
    call    WriteChar
    mov     al, 'W'
    call    WriteChar
    mov     al, '!'
    call    WriteChar
    mov     al, ' '
    call    WriteChar
    mov     al, 'P'
    call    WriteChar
    mov     al, 'r'
    call    WriteChar
    mov     al, 'e'
    call    WriteChar
    mov     al, 's'
    call    WriteChar
    mov     al, 's'
    call    WriteChar
    mov     al, ' '
    call    WriteChar
    mov     al, 'E'
    call    WriteChar
    mov     al, 'N'
    call    WriteChar
    mov     al, 'T'
    call    WriteChar
    mov     al, 'E'
    call    WriteChar
    mov     al, 'R'
    call    WriteChar
    jmp     SW_Done

SW_P1Wins:
    lea     edx, win1Str
    call    WriteString
    jmp     SW_Done

SW_P2Wins:
    lea     edx, win2Str
    call    WriteString

SW_Done:
    ret
ShowWinner ENDP


;  Faizan -- INPUT PROCEDURES

;  ReadKeys
ReadKeys PROC

    call    ReadKey
    jz      RK_Done

    cmp     al, 27
    je      RK_Quit

    cmp     al, 'w'
    je      RK_P1Up
    cmp     al, 'W'
    je      RK_P1Up

    cmp     al, 's'
    je      RK_P1Down
    cmp     al, 'S'
    je      RK_P1Down

    cmp     al, 'i'
    je      RK_P2Up
    cmp     al, 'I'
    je      RK_P2Up

    cmp     al, 'k'
    je      RK_P2Down
    cmp     al, 'K'
    je      RK_P2Down

    jmp     RK_Done

RK_P1Up:
    cmp     paddle1Y, TOP_ROW + 1
    jle     RK_Done
    call    ErasePaddle1
    dec     paddle1Y
    jmp     RK_Done

RK_P1Down:
    movzx   eax, paddle1Y
    add     eax, PAD_HEIGHT
    cmp     eax, BOT_ROW
    jge     RK_Done
    call    ErasePaddle1
    inc     paddle1Y
    jmp     RK_Done

RK_P2Up:
    cmp     paddle2Y, TOP_ROW + 1
    jle     RK_Done
    call    ErasePaddle2
    dec     paddle2Y
    jmp     RK_Done

RK_P2Down:
    movzx   eax, paddle2Y
    add     eax, PAD_HEIGHT
    cmp     eax, BOT_ROW
    jge     RK_Done
    call    ErasePaddle2
    inc     paddle2Y
    jmp     RK_Done

RK_Quit:
    mov     gameOver, 1

RK_Done:
    ret
ReadKeys ENDP


;  WaitForEnter

WaitForEnter PROC

WFE_Loop:
    call    ReadKey
    jz      WFE_Loop
    cmp     al, 13
    jne     WFE_Loop
    ret

WaitForEnter ENDP


;  Faizan -- GAME LOGIC PROCEDURES

;  InitGame
InitGame PROC

    mov     ballX,    BALL_START_X
    mov     ballY,    BALL_START_Y
    mov     ballDX,   1
    mov     ballDY,   1
    mov     paddle1Y, 10
    mov     paddle2Y, 10
    mov     score1,   0
    mov     score2,   0
    mov     gameOver, 0

    call    Clrscr
    ret

InitGame ENDP


;  MoveBall
MoveBall PROC

    call    EraseBall

    ; ballX = ballX + ballDX
    movsx   eax, ballDX
    movzx   ecx, ballX
    add     ecx, eax
    mov     ballX, cl

    ; ballY = ballY + ballDY
    movsx   eax, ballDY
    movzx   ecx, ballY
    add     ecx, eax
    mov     ballY, cl

    ret
MoveBall ENDP


;  CheckCollision
CheckCollision PROC

    ; -- top wall bounce --
    movzx   eax, ballY
    cmp     eax, TOP_ROW + 1
    jg      CC_BotWall
    neg     ballDY
    mov     ballY, TOP_ROW + 1

CC_BotWall:
    ; -- bottom wall bounce --
    movzx   eax, ballY
    cmp     eax, BOT_ROW - 1
    jl      CC_CheckLeft
    neg     ballDY
    mov     ballY, BOT_ROW - 1

CC_CheckLeft:
    ; did ball go off the LEFT edge? --> P2 scores
    movzx   eax, ballX
    cmp     eax, P1_COL         ; ball reached or passed left paddle column
    jg      CC_CheckRight       ; no, ball is still in play on left side

    ; ball is at left edge -- did it hit paddle1?
    movzx   eax, ballY
    movzx   ebx, paddle1Y
    cmp     eax, ebx
    jl      CC_P1Miss           ; ball above paddle

    movzx   ebx, paddle1Y
    add     ebx, PAD_HEIGHT - 1
    cmp     eax, ebx
    jg      CC_P1Miss           ; ball below paddle

    ; HIT paddle1 -- bounce right
    neg     ballDX
    mov     ballX, P1_COL + 1
    jmp     CC_CheckRight

CC_P1Miss:
    ; ball passed left edge without hitting paddle -- P2 gets a point
    inc     score2
    call    DrawScore
    call    ResetBall
    jmp     CC_Done

CC_CheckRight:
    ; did ball go off the RIGHT edge? --> P1 scores
    movzx   eax, ballX
    cmp     eax, P2_COL         ; ball reached right paddle column
    jl      CC_Done             ; no, still in play

    ; ball is at right edge -- did it hit paddle2?
    movzx   eax, ballY
    movzx   ebx, paddle2Y
    cmp     eax, ebx
    jl      CC_P2Miss           ; ball above paddle

    movzx   ebx, paddle2Y
    add     ebx, PAD_HEIGHT - 1
    cmp     eax, ebx
    jg      CC_P2Miss           ; ball below paddle

    ; HIT paddle2 -- bounce left
    neg     ballDX
    mov     ballX, P2_COL - 1
    jmp     CC_Done

CC_P2Miss:
    ; ball passed right edge without hitting paddle -- P1 gets a point
    inc     score1
    call    DrawScore
    call    ResetBall

CC_Done:
    ret
CheckCollision ENDP


;  ResetBall
ResetBall PROC

    mov     ballX,  BALL_START_X
    mov     ballY,  BALL_START_Y
    neg     ballDX
    mov     ballDY, 1

    mov     eax, 500
    call    Delay

    ret
ResetBall ENDP


;  CheckWin
CheckWin PROC

    movzx   eax, score1
    cmp     eax, WIN_SCORE
    je      CW_Over

    movzx   eax, score2
    cmp     eax, WIN_SCORE
    je      CW_Over

    jmp     CW_Done

CW_Over:
    mov     gameOver, 1

CW_Done:
    ret
CheckWin ENDP


;  GameDelay
;  40ms per frame -- increase to slow ball down
GameDelay PROC

    mov     eax, 40
    call    Delay
    ret

GameDelay ENDP


END main